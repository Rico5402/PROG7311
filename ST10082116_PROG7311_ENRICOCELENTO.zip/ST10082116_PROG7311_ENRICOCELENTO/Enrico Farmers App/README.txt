# Farmers Code

This code represents a prototype website for managing farmers and their associated products. It provides functionalities for user authentication, adding farmers and products, and viewing product information.

## Requirements

- .NET Framework
- SQL Server (SQL Express)

## Getting Started

1. Clone the repository or download the code files.
2. Open the solution in your preferred IDE.
3. Update the connection string in the code files (`Farmer.cs`) to point to your SQL Server instance.
4. Build the solution to restore dependencies and compile the code.
5. Deploy the database schema and sample data using the provided SQL scripts.
6. Run the application.

## Functionality

- User Authentication: Farmers and employees are required to log in to access user-specific information.
- Add Farmer: Logged-in employees can add new farmers to the database.
- Add Product: Logged-in farmers can add new products to their profile in the database.
- View Products: Logged-in employees can view the list of all products supplied by a specific farmer.
- Filter Products: Logged-in employees can filter the displayed list of products supplied by a specific farmer based on the date range or product type.

## Dependencies

- System.Data.SqlClient: Used for database connectivity and executing SQL queries.
- Microsoft.AspNetCore.Mvc: Provides the framework for creating web applications using the Model-View-Controller (MVC) pattern.
- Microsoft.AspNetCore.Mvc.RazorPages: Enables building web pages using the Razor syntax.


## License



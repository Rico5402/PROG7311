﻿namespace Farmers
{
    public class Employee
    {
        public int EmployeeID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Address { get; set; }
        public string ContactNumber { get; set; }
        public string Email { get; set; }
        public int RoleID { get; set; }

        public static Employee Login(string email, string password)
        {
            // Implement employee login logic
            return null;
        }
    }
}

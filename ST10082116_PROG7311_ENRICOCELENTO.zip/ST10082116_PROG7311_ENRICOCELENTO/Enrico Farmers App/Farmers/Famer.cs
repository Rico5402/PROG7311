﻿using System.Data.SqlClient;

namespace Farmers
{
    public class Farmer
    {
        public int FarmerID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Address { get; set; }
        public string ContactNumber { get; set; }
        public string Email { get; set; }
        public int RoleID { get; set; }

        public string FullName => FirstName + " " + LastName;

        public static Farmer Login(string email, string password)
        {
            string connectionString = "Data Source=LENRICOC\\SQLEXPRESS;Initial Farming=DatabaseName;Integrated Security=True;";
            string query = "SELECT * FROM Farmers WHERE Email = @Email AND Password = @Password";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Email", email);
                    command.Parameters.AddWithValue("@Password", password);

                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    if (reader.HasRows)
                    {
                        reader.Read();
                        Farmer farmer = new Farmer
                        {
                            FarmerID = Convert.ToInt32(reader["FarmerID"]),
                            FirstName = reader["FirstName"].ToString(),
                            LastName = reader["LastName"].ToString(),
                            Address = reader["Address"].ToString(),
                            ContactNumber = reader["ContactNumber"].ToString(),
                            Email = reader["Email"].ToString(),
                            RoleID = Convert.ToInt32(reader["RoleID"])
                        };

                        reader.Close();
                        return farmer;
                    }
                }
            }

            return null;
        }

        public static List<Farmer> GetAllFarmers()
        {
            List<Farmer> farmers = new List<Farmer>();

            string connectionString = "Data Source=Lenricoc\\SQLEXPRESS;Initial Farming=DatabaseName;Integrated Security=True;";
            string query = "SELECT * FROM Farmers";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            Farmer farmer = new Farmer
                            {
                                FarmerID = Convert.ToInt32(reader["FarmerID"]),
                                FirstName = reader["FirstName"].ToString(),
                                LastName = reader["LastName"].ToString(),
                                Address = reader["Address"].ToString(),
                                ContactNumber = reader["ContactNumber"].ToString(),
                                Email = reader["Email"].ToString(),
                                RoleID = Convert.ToInt32(reader["RoleID"])
                            };

                            farmers.Add(farmer);
                        }
                    }

                    reader.Close();
                }
            }

            return farmers;
        }

        public static Farmer GetFarmerByID(int farmerID)
        {
            string connectionString = "Data Source=Lenricoc\\SQLEXPRESS;Initial Farming=DatabaseName;Integrated Security=True;";
            string query = "SELECT * FROM Farmers WHERE FarmerID = @FarmerID";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@FarmerID", farmerID);

                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    if (reader.HasRows)
                    {
                        reader.Read();
                        Farmer farmer = new Farmer
                        {
                            FarmerID = Convert.ToInt32(reader["FarmerID"]),
                            FirstName = reader["FirstName"].ToString(),
                            LastName = reader["LastName"].ToString(),
                            Address = reader["Address"].ToString(),
                            ContactNumber = reader["ContactNumber"].ToString(),
                            Email = reader["Email"].ToString(),
                            RoleID = Convert.ToInt32(reader["RoleID"])
                        };

                        reader.Close();
                        return farmer;
                    }
                }
            }

            return null;
        }

        public List<Product> GetProducts()
        {
            List<Product> products = new List<Product>();

            string connectionString = "Data Source=Lenricoc\\SQLEXPRESS;Initial DatabaseName=Farming;Integrated Security=True;";
            string query = "SELECT * FROM Products WHERE FarmerID = @FarmerID";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@FarmerID", FarmerID);

                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            Product product = new Product
                            {
                                ProductID = Convert.ToInt32(reader["ProductID"]),
                                FarmerID = Convert.ToInt32(reader["FarmerID"]),
                                ProductName = reader["ProductName"].ToString(),
                                Description = reader["Description"].ToString(),
                                Price = Convert.ToDecimal(reader["Price"]),
                                Quantity = Convert.ToInt32(reader["Quantity"])
                            };

                            products.Add(product);
                        }
                    }

                    reader.Close();
                }
            }

            return products;
        }

        public List<Product> GetProductsByDateAndType(DateTime startDate, DateTime endDate, string productType)
        {
            List<Product> products = new List<Product>();

            string connectionString = "Data Source=Lenricoc\\SQLEXPRESS;Initial Farming=DatabaseName;Integrated Security=True;";
            string query = "SELECT * FROM Products WHERE FarmerID = @FarmerID AND ProductType = @ProductType " +
                "AND CreatedDate >= @StartDate AND CreatedDate <= @EndDate";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@FarmerID", FarmerID);
                    command.Parameters.AddWithValue("@ProductType", productType);
                    command.Parameters.AddWithValue("@StartDate", startDate);
                    command.Parameters.AddWithValue("@EndDate", endDate);

                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            Product product = new Product
                            {
                                ProductID = Convert.ToInt32(reader["ProductID"]),
                                FarmerID = Convert.ToInt32(reader["FarmerID"]),
                                ProductName = reader["ProductName"].ToString(),
                                Description = reader["Description"].ToString(),
                                Price = Convert.ToDecimal(reader["Price"]),
                                Quantity = Convert.ToInt32(reader["Quantity"])
                            };

                            products.Add(product);
                        }
                    }

                    reader.Close();
                }
            }

            return products;
        }
    }
}

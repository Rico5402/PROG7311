﻿namespace Farmers
{
       public partial class FarmersMarketWebApp : Farmer
    {
 

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            string email = txtEmail.Text;
            string password = txtPassword.Text;
            string role = ddlRole.SelectedValue;

            if (role == "Farmer")
            {
                Farmer farmer = Farmer.Login(email, password);
                if (farmer != null)
                {
                    Session["User"] = farmer;
                    Response.Redirect("FarmerDashboard.aspx");
                }
                else 
                {
                    MessageBox.Show("Invalid login");
                }
            }
            else if (role == "Employee")
            {
                Employee employee = Employee.Login(email, password);
                if (employee != null)
                {
                    Session["User"] = employee;
                    Response.Redirect("EmployeeDashboard.aspx");
                }
                else
                {
                    MessageBox.Show("Invalid login");
                }
            }
        }

        private void BindFarmers()
        {
            List<Farmer> farmers = Farmer.GetAllFarmers();
            ddlFarmers.DataSource = farmers;
            ddlFarmers.DataTextField = "FullName";
            ddlFarmers.DataValueField = "FarmerID";
            ddlFarmers.DataBind();
        }

        protected void ddlFarmers_SelectedIndexChanged(object sender, EventArgs e)
        {
            int farmerID = Convert.ToInt32(ddlFarmers.SelectedValue);
            Farmer farmer = Farmer.GetFarmerByID(farmerID);
            if (farmer != null)
            {
                List<Product> products = farmer.GetProducts();
            }
        }

        protected void btnFilter_Click(object sender, EventArgs e)
        {
            int farmerID = Convert.ToInt32(ddlFarmers.SelectedValue);
            DateTime startDate = DateTime.Parse(txtStartDate.Text);
            DateTime endDate = DateTime.Parse(txtEndDate.Text);
            string productType = ddlProductType.SelectedValue;

            Farmer farmer = Farmer.GetFarmerByID(farmerID);
            if (farmer != null)
            {
                List<Product> filteredProducts = farmer.GetProductsByDateAndType(startDate, endDate, productType);
            }
        }
    }
}
